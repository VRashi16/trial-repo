// Create a web page that displays the current date in the format specified as in example below. Also as per
// current time, suitable greeting should be printed.
// Today is Monday, 24 April 2000, Welcome, and Good Afternoon to You.
// Number of days left till end of year : <display> --></display>



var d = new Date();
// document.write(d+"<br>");
// var a = d.toString();
// a=d.getFullYear();
// document.write(a+"<br>");

const days=['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
day=days[d.getDay()];

date=d.getDate();

const months=["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var month=months[d.getMonth()];

const year=d.getFullYear();

document.write("Today is "+day+", "+date+" "+month+" "+year+", Welcome, and Good Afternoon to You.");


document.write(`<br>Number of days left till end of year: `);

// var s=new Date(year,12,31);
// document.write(s);

// var daysleft=365-d.getDate();
// document.write(daysleft);