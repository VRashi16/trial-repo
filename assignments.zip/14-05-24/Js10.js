
var d = new Date();
document.write(d+"<br>");
var a = d.toString();
a=d.getFullYear();
document.write(a+"<br>");