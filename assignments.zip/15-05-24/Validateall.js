function validatename(name){
    var Regex = /[a-zA-Z]/g;
    //length
    if(name.length<=0){
    document.getElementById("ta1").innerHTML="Length is too short!"
    }

    //null and regex
    if(name != null && name.match(Regex)){
        document.getElementById("nameresult").innerHTML = "";
    }
    else{
        document.getElementById("nameresult").innerHTML = "Name should be only alphabets!";
    }
    //First etter Capitalisation
    var Regex1=/^[A-Z][a-z]*$/
    if(name.match(Regex1)){
        document.getElementById("nameresult").innerHTML = "";

    }else{
        document.getElementById("nameresult").innerHTML = "First letter should be capitalised";
    }
}

function validateall(){
    var name=document.getElementById("ta1").value;
    validatename(name.trim())
}