#!/bin/bash

# Check if the user provided a file path as an argument
if [ -z "$1" ]; then
    echo "Usage: $0 <file_path>"
    exit 1
fi

# Check if the file path exists
if [ ! -e "$1" ]; then
    echo "File not found: $1"
    exit 1
fi

# Check if the file path is a directory
if [ -d "$1" ]; then
    echo "$1 is a directory."
else
    echo "$1 is not a directory."
fi


#
sahil@ubuntu-5515:~/Desktop/OSlab1$ bash q2.sh
Usage: q2.sh <file_path>
sahil@ubuntu-5515:~/Desktop/OSlab1$ bash q2.sh /home/sahil/Desktop/OSlab1/log.txt
/home/sahil/Desktop/OSlab1/log.txt is not a directory.
sahil@ubuntu-5515:~/Desktop/OSlab1$ bash q2.sh /home/sahil/Desktop/OSlab1
/home/sahil/Desktop/OSlab1 is a directory.
sahil@ubuntu-5515:~/Desktop/OSlab1$
