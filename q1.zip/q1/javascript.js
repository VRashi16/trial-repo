const express = require('express');
const app = express();
const port = 3000;

// Middleware to parse JSON request bodies
app.use(express.json());

// In-memory storage for books
let books = [];

// Generate a unique ID for a new book
function generateId() {
  return books.length + 1;
}

// Create a new Book object
function createBook(id, name, author, price) {
  return { id, name, author, price };
}

// Add a new book to the in-memory storage
function addBook(book) {
  books.push(book);
}

// Get all books
app.get('/books', (req, res) => {
  res.json(books);
});

// Add a new book
app.post('/books', (req, res) => {
  const { name, author, price } = req.body;
  const id = generateId();
  const newBook = createBook(id, name, author, price);
  addBook(newBook);
  res.json(newBook);
});

// Start the server
app.listen(3000, () => {
  console.log(`Server is running at http://localhost:${port}`);
});