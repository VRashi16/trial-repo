const exp = require('constants')
const express = require('express')
const app = express()
const port = 3000

let books = [];
let id =1;

app.use(express.json());

app.post('/addbook',(req,res)=>{
    const {name, author, price} = req.body;
    if(!name || !author || !price){
        return res.status(400).send({message: 'Please provide all book details'})
    }
    const book = {id, name, author, price};
    books.push(book);
    id++;
    res.json(book);

});

app.listen(port, ()=>{
    console.log("Running on http://localhost:3000/");
})