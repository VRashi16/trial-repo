// Client Module

var gr = require("./greet.js")
console.log(gr.greet())