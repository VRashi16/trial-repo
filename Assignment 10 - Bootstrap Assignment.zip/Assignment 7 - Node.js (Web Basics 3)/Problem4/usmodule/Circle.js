exports.calcArea = function(radius) {
    return Math.PI*Math.pow(radius, 2)
}

exports.calcCircumference = function(radius) {
    return 2*Math.PI*radius
}

exports.calcDiameter = function(radius) {
    return 2*radius
}