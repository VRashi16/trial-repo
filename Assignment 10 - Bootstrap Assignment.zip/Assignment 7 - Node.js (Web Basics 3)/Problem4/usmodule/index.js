exports.f_one = require('./Circle.js')
exports.f_two = require('./Rectangle.js')
exports.f_three = require('./Triangle.js')