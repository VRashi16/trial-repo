var cal = require("./calc.js")

console.log(cal.add(3,4));
console.log(cal.subtract(3,6))
console.log(cal.multiply(3,4))
console.log(cal.divide(16,4))
console.log(cal.square(5))
console.log(cal.sum(3,4,5,7))