var str = require("./string.js")

console.log(str.palindrome("pulup"));

console.log(str.upper("Change to Upper"))

var siteArr = ["www.google.com", "www.amazon.co.in", "www.msn.com", "in.answers.yahoo.com", "www.coderanch.com", "en.m.wikipedia.com"];

console.log(str.searchh(siteArr))