const calc = require('./mymodule');

console.log(calc.add(2, 3)); // 5
console.log(calc.subtract(7, 4)); // 3
console.log(calc.multiply(3, 5)); // 15
console.log(calc.divide(10, 2)); // 5
console.log(calc.square(4)); // 16
console.log(calc.sum(1, 2, 3, 4)); // 10