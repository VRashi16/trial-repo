const circle = require('./circle');
const rectangle = require('./rectangle');
const triangle = require('./triangle');

console.log('Circle:');
console.log(`Area: ${circle.calcArea(5)}`);
console.log(`Circumference: ${circle.calcCircumference(5)}`);
console.log(`Diameter: ${circle.calcDiameter(5)}`);

console.log('\nRectangle:');
console.log(`Area: ${rectangle.calcArea(4, 6)}`);
console.log(`Perimeter: ${rectangle.calcPerimeter(4, 6)}`);

console.log('\nTriangle:');
console.log(`Is Equilateral: ${triangle.isEquilateral(5, 5, 5)}`);
console.log(`Perimeter: ${triangle.calcPerimeter(5, 5, 5)}`);