function factorial(n) {
    if (n === 0 || n === 1) {
      return 1;
    }
    return n * factorial(n - 1);
  }
  
  function myprime(n) {
    if (n < 2) {
      return false;
    }
    for (let i = 2; i < Math.sqrt(n); i++) {
      if (n % i === 0) {
        return false;
      }
    }
    return true;
  }
  
  function printable(n) {
    for (let i = 1; i <= 10; i++) {
      console.log(`${n} * ${i} = ${n * i}`);
    }
  }
  
  module.exports = {
    factorial,
    myprime,
    printable,
  };