const readline = require('readline');
const mymodule = require('./mymodule');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question('Enter a number: ', (answer) => {
  const num = parseInt(answer, 10);
  if (num < 5) {
    console.log(`Factorial of ${num} is ${mymodule.factorial(num)}`);
  } else if (num > 5 && num < 10) {
    mymodule.printable(num);
  } else {
    if (mymodule.myprime(num)) {
      console.log(`${num} is a prime number`);
    } else {
      console.log(`${num} is not a prime number`);
    }
  }
  rl.close();
});

rl.on('close', () => {
  console.log('Exiting the program...');
});