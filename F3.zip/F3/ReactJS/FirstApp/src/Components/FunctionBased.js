function FunctionBased(props){
    return(
        <div className="App-header1">
            <h3>This is Function based Component Stateless and name From Props is {props.name}</h3>
        </div>
    );
}
export default FunctionBased;