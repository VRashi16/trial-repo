import '../App.css'

function Footer(){
    return(
        <div className="App-header">
 <footer>This is Footer</footer></div>
    );
}

export default Footer;