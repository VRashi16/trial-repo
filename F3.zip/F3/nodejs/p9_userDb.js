exports.users = [{username:"kinjal123", password:"kinjal"},
                {username:"kajal123", password:"kajal"},
                {username:"test123",password:"test"}
                ]