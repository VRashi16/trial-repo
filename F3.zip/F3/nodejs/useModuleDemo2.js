let script2 = require('./moduleDemo2');
console.log(user.uid);
