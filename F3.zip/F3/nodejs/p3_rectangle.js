exports.calcArea = function(length, breadth){
    return length * breadth;
}

exports.calcPerimeter = function(length, breadth){
    return 2 * (length + breadth);
}