let script2 = require('./moduleDemo1');
console.log(script2.addition(2,3));
console.log(script2.subtract(20,3));
console.log(script2.multiply(2,3));
console.log(script2.divide(27,3));

console.log(script2.factorial(8));
