const print = require('./p4_print_no_module')
console.log(print.print1to100());