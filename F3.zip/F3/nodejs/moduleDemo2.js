user={uid:12,uname:'yyyy'}

module.exports={
  user: user
}