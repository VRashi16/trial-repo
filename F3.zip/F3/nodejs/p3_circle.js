exports.calcArea = function(radius){
    return 3.14 * radius * radius;
}

exports.calcCircumference = function(radius){
    return 2* 3.14 * radius;
}

exports.calcDiameter = function(radius){
    return 2 * radius;
}