const calc = require("./p1_calc");
console.log("sum = ",calc.add(10,20)); 
console.log("subtract = ",calc.subtract(10,20)); 
console.log("multiplication = ",calc.multiply(10,20)); 
console.log("divide = ",calc.divide(20,0));
console.log("square = ",calc.square(10)); 
console.log("sum of all no = ",calc.sum(10,20,30,40)); 