const express = require('express');
const mysql = require('mysql2');
const app = express();
const path = require('path');
const port = 3000;

const db = mysql.createConnection({
    host:'localhost',
    user: 'root',
    password: 'rahuls',
    database: 'paper'
});

app.use(express.static(path.join(__dirname)))

app.use(express.urlencoded({ extended: true }));

app.get('/' ,(req, res)=>{
    res.sendFile(path.join(__dirname, 'paper.html'))
})

db.connect((err) => {
    if(err){
        console.error('Error something:',err);
        return;
    }
    console.log("Connected as id : "+ db.threadId);
});


app.get('/getbook/:bookid',(req, res)=>{
    const id = parseInt(req.params.bookid);
    const query = `SELECT * FROM books WHERE bookid =?`;
    db.query(query, id, (err, result) => {
        if (err) {
            console.error('Error something:',err);
            return res.status(500).send({message: 'Error fetching book'});
        }
        else
            res.send(result[0]);
    });
});

app.post('/updatebook',(req, res)=>{
    const id = parseInt(req.body.bookid);
    const name = req.body.bookname;
    const price = req.body.price;
    const query = `UPDATE books SET bookname=? , price =? WHERE bookid=?`;
    db.query(query, [name, price, id], (err, result) => {
        if (err) {
            console.error('Error something:',err);
            res.status(500).send({message: 'Error fetching book'});
        } else {
            res.send({ message: 'Book price updated successfully' });
        }
    });
})

app.listen(port, ()=>{
    console.log('Server is running on http://localhost:3000/');
})
