
import './App.css';
import Addition from './components/Addition';

function App() {
  return (
    <div className="App">
      <Addition/>
    </div>
  );
}

export default App;
