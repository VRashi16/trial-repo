const plus=require("./Q1")
console.log(plus.add(10,20));

const min=require("./Q1")
console.log(min.sub(30,20));

const mult=require("./Q1")
console.log(mult.mul(30,20));

const divi=require("./Q1")
console.log(divi.division(30,20));

const squ=require("./Q1")
console.log(squ.square(3));

const a=require("./Q1")
console.log(a.addAll(3,4,5));
