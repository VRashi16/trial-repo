 exports.add=function(a,b)
 {
    return a+b;
 }
 exports.sub=function(a,b)
 {
    return a-b;
 }
 exports.mul=function(a,b)
 {
    return a*b;
 }
 exports.division=function(a,b)
 {
    return a/b;
 }
 exports.square=function(a)
 {
    return a*a;
 }
 exports.addAll=function(a,b,c,...d)
 {
    var ans=0;
   for(var i=0;i<d.length;i++)
    {
        ans=ans+d[i]
    }
    ans=ans+a+b+c;
    return ans;
 }

 

