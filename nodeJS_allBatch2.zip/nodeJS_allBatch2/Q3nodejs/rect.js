exports.calcArea=function(length,breadth){
    return parseInt(length)*parseInt(breadth);
}

exports.calcPeri=function(length,breadth){
    return 2*(parseInt(length)+parseInt(breadth));
}

