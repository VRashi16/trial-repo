const http = require('http')
const fs = require('fs')
const url = require('url')
const path = require('path')
const circle = require("./circle")
const rectangle = require("./rect")
const triangle = require("./triangle")

var server = http.createServer(function (req, resp) {
    console.log(req.url + "  " + req.method)
    var p = url.parse(req.url, true)
    console.log("link iss")
    console.log(p)
    resp.writeHeader(200, { 'Content-Type': 'text/html' })
    console.log("path iss")
    console.log(p.pathname);

    switch (p.pathname) {
        case '/form':
            console.log("form")
            var rs = fs.createReadStream("./Q3.html")
            rs.pipe(resp)
            break;
        case '/submit-shape':
            console.log("submit\n")
            switch (p.query.shapeip) {
                case 'circle':
                    var rs = fs.createReadStream("./circle.html");
                    rs.pipe(resp)
                    break;
                case 'triangle':
                    var rs = fs.createReadStream("./triangle.html");
                    rs.pipe(resp)
                    break;
                case 'rectangle':
                    var rs = fs.createReadStream("./rect.html");
                    rs.pipe(resp)
                    break;
            }
            break;
        case '/circle':
            var radius = p.query.circleradius;
            var area = circle.calcArea(radius);
            var peri = circle.calcPeri(radius);
            var dia = circle.calcDiameter(radius);
            resp.write("Area of Circle: " + `${area}` + "\n");
            resp.write("Perimeter of Circle: " + `${peri}` + "\n")
            resp.write("Diameter of Circle: " + `${dia}` + "\n");
            resp.end();
            break;
        case '/rect':
            var length = p.query.len;
            var breadth=p.query.breadth;
            var area = rectangle.calcArea(length, breadth);
            var peri = rectangle.calcPeri(length, breadth);
            resp.write("Area of rectangle: " + `${area}` + "\n");
            resp.write("Perimeter of rectangle: " + `${peri}` + "\n")
            resp.end();
            break;
        case '/triangle':
            var side1 = p.query.side1;
            var side2 = p.query.side2;
            var side3 = p.query.side3;
            var peri = triangle.calcPeri(side1, side2, side3);
            var isEqui = triangle.isEquilateral(side1, side2, side3);
            resp.write("Perimeter of triangle: " + `${peri}` + "\n");
            resp.write("Given triangle is equilateral or not? " + `${isEqui}` + "\n")
            break;
        default:
            console.log("in default");
            console.log("ended")
            resp.end();
            break;
    }

})
server.listen(3001, function () {
    console.log("server is running on port 3001")
})