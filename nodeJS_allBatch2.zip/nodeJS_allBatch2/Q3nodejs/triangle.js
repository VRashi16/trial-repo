exports.isEquilateral=function(side1,side2,side3){
    if(side1===side2 && side1===side3){
        return true;
    }
    return false;
}

exports.calcPeri=function(side1,side2,side3){
    return (parseInt(side1)+parseInt(side2)+parseInt(side3));
}