
exports.calcArea=function(radius){
    return radius*radius*(Math.PI);
}


exports.calcPeri=function(radius){
    return 2*radius*(Math.PI);
}


exports.calcDiameter=function(radius){
    return 2*radius;
}