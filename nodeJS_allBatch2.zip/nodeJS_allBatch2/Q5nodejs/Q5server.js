const fs = require('fs')
const http = require('http')
const url = require('url')
const path = require('path')
const { log } = require('console')
const serevr = http.createServer(function (req, resp) {
    const q = url.parse(req.url, true)
    resp.writeHeader(200, { 'Content-Type': 'text/html' })
    switch (q.pathname) {
        case "/":
            resp.write("before reading async file<br>")
            fs.readFile("mydata.txt", function (err, data) {
                if (err) {
                    resp.write("error occured")
                } else {
                    resp.write("data read successfully <br>")
                    resp.write(data+"<br>")
                    resp.write("length is: ")
                    resp.write(`${data.length}`+"<br><br>")               
                }
                // resp.end();
            })
            
            resp.write("after reading txt file <br>")
            fs.readFile("myfile.data", function (err, data) {
                if (err) {
                    console.log("error occured")
                    resp.write("error occured")
                } else {
                    resp.write("data read successfully <br>")
                    resp.write(data+"<br>")
                    resp.write("length is: ")
                    resp.write(`${data.length}`)               
                }
                // resp.end();
            })
            break;
        default:
            console.log("in def")
            resp.end();
            break;
    }
})

serevr.listen(4002, function () {
    console.log("running on 4002")
})
