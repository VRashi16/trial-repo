const f1=require("./Q2")
console.log(f1.fact(5));

const p1=require("./Q2")
console.log(p1.prime(9));

const print1=require("./Q2")
console.log(print1.printTable(5));