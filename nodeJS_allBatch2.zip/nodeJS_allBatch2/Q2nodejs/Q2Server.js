const http = require('http');
const fs = require('fs')
const url = require('url')
const m1 = require("./Q2");
const path = require('path');
var server = http.createServer(function (req, resp) {
    console.log(req.url + "---->" + req.method)
    var p = url.parse(req.url, true)
    console.log("p: ", p);
    resp.writeHeader(200, { 'content-text': 'text/html' })
     console.log(p.pathname);
    switch (p.pathname) {
        case "/form23":
            console.log("in fomrm")
            var rs = fs.createReadStream("Q2Form.html")
            rs.pipe(resp)
            break;
        case "/submit-data":
            console.log("in submit")
                var number= p.query.num1; 
                resp.write("number is: ")   
                resp.write(number+"\n");
                if(number<=5){
                    resp.write("less than 5 \n")
                    var ans=m1.fact(number);
                    resp.write("fact is: "+`${ans}`);
                    resp.write("\n")

                }else if(number>5 && number<10){
                    resp.write("printtable")
                    var ans=m1.printTable(number);
                    resp.write("table is: "+`${ans}`);
                    resp.write("\n")
                }else{
                    resp.write("greater than 10");
                    resp.write("\n")
                    var ans=m1.prime(number);
                    resp.write("prime is: "+`${ans}`);
                }
                resp.end();
                break;
        default:
            console.log("in default")
            console.log("ended");
            resp.end();
            break;

    }

})

server.listen(3001, function () {
    console.log("server is running on port 3001");
})