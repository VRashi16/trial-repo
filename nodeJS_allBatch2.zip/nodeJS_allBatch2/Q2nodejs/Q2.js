exports.fact=function(num)
{
    var f=1;
    for(var i=1;i<=num;i++)
        {
            f=f*i;
        }
        return f;
}

 exports.prime=function(num) {
    if (num <= 1) return false; 
    for (let i = 2; i < num; i++) {
        if (num % i === 0) {
            return false; 
        }
    }
    return true;
}


exports.printTable=function(num)
{
    var str="";
    for(var i=1;i<=10;i++)
    {
            str+=num+"*"+i+"="+(num*i)+"\n"
    }
    return str;
}