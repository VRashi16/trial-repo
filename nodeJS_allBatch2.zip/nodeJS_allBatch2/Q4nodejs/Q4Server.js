const http = require('http')
const fs = require('fs')
const path = require('path')
const url = require('url')

var server = http.createServer(function (req, resp) {
    var p = url.parse(req.url, true);
    resp.writeHeader(200, { 'Content-Type': 'text/html' })
    switch (p.pathname) {
        case '/':
            console.log("in form")
            for (var i = 0; i < 100; i++) {
                if (i % 3 === 0) {
                    resp.write("<span>fizz</span>")
                } else if (i % 5 === 0) {
                    resp.write("<span>buzz</span>")
                } else if (i % 3 === 0 && i % 5 === 0) {
                    resp.write("<span>fizzbuzz</span>")
                } else {
                    resp.write(`${i}`)
                }
                resp.write("<br>")
            }
            resp.end();
            break;
        default:
            resp.end();
            break;
    }
})


server.listen(3000, function () {
    console.log('server is running on port 3000')
})