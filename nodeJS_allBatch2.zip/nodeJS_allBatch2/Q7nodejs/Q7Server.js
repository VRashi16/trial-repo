const fs = require('fs')
const http = require('http')
const url = require('url')
const path = require('path')


var server = http.createServer(function (req, resp) {
    var p = url.parse(req.url, true)
    resp.writeHeader(200, { 'Content-Type': 'text/html' })
    switch (p.pathname) {
        case "/":
            const data = fs.readFileSync("mydata.txt", 'utf-8');
            const lines = data.split('\n');
            for (var i = 0; i < lines.length; i++) {
                resp.write(`${i + 1}.${lines[i]}`+"<br>")
                
            }
            resp.end();
            break;
        default:
            console.log("in def")
            resp.end();
            break;
    }
})

server.listen(5000,function(){
    console.log("running on 5000")
})






