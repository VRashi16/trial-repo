const http = require('http')
const path = require('path')
const url = require('url')
const fs = require('fs')
const express = require('express')
const app = express();
const m1 = require("./prime")

app.get('/form', (req, res) => {
    res.sendFile(path.join(__dirname, "./Q10form.html"))
    console.log("in form")
})
app.get('/submit', (req, res) => {
    var num = parseInt(req.query.num);
    var ans = m1.isPrimeNum(num);
    res.send("user entered value: " + num+ " <br>is prime: " + ans)
})

app.listen(5000, function () {
    console.log(`Example app listening on port 5000`)
})