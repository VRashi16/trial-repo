const http = require("http")
const path = require("path")
const url = require("url")
const express = require('express')
const app = express();
const fs = require("fs")

const server = http.createServer(function (req, resp) {
    var p = url.parse(req.url, true)
    resp.writeHeader(200, { 'Content-Type': 'text/html' })
    switch (p.pathname) {
        case '/form':
            var rs = fs.createReadStream("LoginForm.html")
            rs.pipe(resp);
            break;
        case "/submit-logindata":
            console.log(" after submission")
            const users = [["kanchan", "hello"], ["ruchita", "bye"],["rohit", "done"]];
            const tempsuser = [];
            var pass = p.query.password;
            var user = p.query.username;
            if (pass.length > 6) {
                resp.write("Password must be less than 6 chararacters<br>")
                resp.write("<a href='LoginForm.html'>Back</a>")
            }
            else {
                const user1 = users.find(([u, p]) => u === user && p === pass);
                console.log(user1)
                if (user1) {
                    var rs = fs.createReadStream("success.html")
                    rs.pipe(resp);
                } else {
                    var rs = fs.createReadStream("failure.html")
                    rs.pipe(resp);
                    resp.write("<a href='LoginForm.html'>Back</a>")
                }
            }
            resp.flushHeaders();
            break;
        case "/LoginForm.html":
            var rs = fs.createReadStream("LoginForm.html")
            rs.pipe(resp);
            break;
        default:
            resp.end();
            break;
    }
})

server.listen(3004, function () {
    console.log("Server is running on port 3004")
})