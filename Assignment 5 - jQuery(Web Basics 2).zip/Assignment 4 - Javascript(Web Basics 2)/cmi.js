function distance(d) {
    value = d*2.54;
    return value;
}